"""
app.py
======

WHAT: The Streamlit web UI for ResolveIT.
WHY:  Streamlit lets us build a simple, functional chat-style interface in
      pure Python (no separate frontend framework needed), which fits an
      MVP focused on demonstrating the RAG + agent pipeline rather than
      frontend engineering.
WHERE: Run with `streamlit run app.py`.
"""

import streamlit as st

from src.agent import run_agent
from src.config import settings
from src.retriever import VectorStoreNotInitializedError

st.set_page_config(page_title="ResolveIT - Agentic AI IT Helpdesk", page_icon="🛠️", layout="wide")

st.title("🛠️ ResolveIT — Agentic AI IT Helpdesk")
st.caption(
    "A portfolio MVP demonstrating Retrieval-Augmented Generation (RAG), a local "
    "Chroma vector database, and a LangGraph agent with real tool calling — "
    "running fully offline on local models via Ollama."
)

with st.expander("About this project", expanded=False):
    st.markdown(
        """
This assistant answers IT troubleshooting questions by:
1. Searching a local knowledge base of troubleshooting documents (RAG).
2. Optionally checking simulated real-time system status (a tool call).
3. Producing a grounded, structured troubleshooting response — never
   inventing procedures that aren't backed by retrieved documents or tools.

**Tech stack:** LangChain · LangGraph · ChromaDB · Ollama (local LLM + embeddings) · Streamlit

**Runs 100% locally** - no cloud API key, no external calls, no cost per
query. You only need Ollama installed with the `llama3.2` and
`nomic-embed-text` models pulled (see README).
        """
    )

# --- Startup configuration check -------------------------------------------------
config_problems = settings.validate_for_runtime()
if config_problems:
    st.error("Configuration problem(s) detected:")
    for p in config_problems:
        st.markdown(f"- {p}")
    st.stop()

# --- Session state for chat history -----------------------------------------------
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # list of {"role", "content", "trace": {...}}

# --- Render existing chat history --------------------------------------------------
for turn in st.session_state.chat_history:
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        trace = turn.get("trace")
        if trace:
            with st.expander("🔍 Retrieved sources & tool activity"):
                if trace["tool_calls"]:
                    for call in trace["tool_calls"]:
                        st.markdown(f"**Tool called:** `{call['name']}`  \n**Args:** `{call['args']}`")
                        st.code(call["result"], language="text")
                else:
                    st.markdown("_No tools were called for this response._")

# --- Chat input ----------------------------------------------------------------
user_query = st.chat_input("Describe your IT issue (e.g. 'My VPN keeps disconnecting')...")

if user_query is not None:
    query_text = user_query.strip()

    if not query_text:
        st.warning("Please enter a non-empty question.")
    else:
        st.session_state.chat_history.append({"role": "user", "content": query_text})
        with st.chat_message("user"):
            st.markdown(query_text)

        with st.chat_message("assistant"):
            with st.spinner("Analyzing issue, searching knowledge base, and consulting tools..."):
                try:
                    result = run_agent(query_text)
                    answer = result["final_answer"]
                    trace = {"tool_calls": result["tool_calls"]}
                except VectorStoreNotInitializedError as exc:
                    answer = (
                        "⚠️ The knowledge base index has not been built yet.\n\n"
                        f"Details: {exc}\n\n"
                        "Run `python ingest.py` from the project root, then restart this app."
                    )
                    trace = None
                except ValueError as exc:
                    answer = f"⚠️ {exc}"
                    trace = None
                except RuntimeError as exc:
                    answer = f"⚠️ The assistant hit an error: {exc}"
                    trace = None
                except Exception as exc:  # noqa: BLE001 - last-resort UI guard
                    answer = f"⚠️ An unexpected error occurred: {exc}"
                    trace = None

            st.markdown(answer)
            if trace:
                with st.expander("🔍 Retrieved sources & tool activity"):
                    if trace["tool_calls"]:
                        for call in trace["tool_calls"]:
                            st.markdown(
                                f"**Tool called:** `{call['name']}`  \n**Args:** `{call['args']}`"
                            )
                            st.code(call["result"], language="text")
                    else:
                        st.markdown("_No tools were called for this response._")

        st.session_state.chat_history.append({
            "role": "assistant",
            "content": answer,
            "trace": trace,
        })
