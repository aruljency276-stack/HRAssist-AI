"""
agent.py
========

WHAT: Implements the agent workflow using LangGraph.
WHY:  A plain LLM call is "stateless" and can only respond with text. An
      "agent" adds a decision loop: the LLM can look at the user's question,
      decide it needs more information, call a tool to get that information,
      look at the tool's result, and then decide again (call another tool,
      or answer). LangGraph models this as a small state machine ("graph")
      with two node types here:
        - "agent" node: calls the LLM (with tools bound) and gets back
          either a final answer or a request to call one or more tools.
        - "tools" node: actually executes whichever tool(s) the LLM asked
          for, and appends the results back into the conversation.
      The graph loops between these two nodes until the LLM produces a
      final answer with no further tool calls.
WHERE: Used by app.py to run each user query through the full
       retrieve/tool-call/answer pipeline.

ARCHITECTURE (matches the project brief):

    User Query
        |
        v
    [agent node] --(LLM decides)--> calls tool? --yes--> [tools node] --+
        ^                                                                |
        |________________________________________________________(loop)+
        |
        no more tool calls needed
        v
    Final grounded troubleshooting response
"""

from __future__ import annotations

from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages

from src.config import settings
from src.prompts import SYSTEM_PROMPT
from src.tools import ALL_TOOLS


class AgentState(TypedDict):
    """The state passed between nodes in the graph.

    WHY a TypedDict: LangGraph needs a well-defined schema for what data
    flows through the graph. `messages` is the running conversation
    (system prompt + user question + any tool calls/results + final
    answer). `add_messages` is a LangGraph helper that appends new messages
    to the list instead of overwriting it, which is what we want for a
    conversation history.
    """

    messages: Annotated[list[AnyMessage], add_messages]


def _build_llm() -> ChatOllama:
    # ChatOllama talks to the local Ollama server over HTTP - no API key,
    # no cloud call, no per-token cost. If the server isn't running, or the
    # model hasn't been pulled (`ollama pull llama3.2`), the error surfaces
    # clearly the first time the LLM is actually invoked below.
    llm = ChatOllama(
        model=settings.llm_model,
        temperature=settings.llm_temperature,
        base_url=settings.ollama_base_url,
    )
    # Binding tools tells the LLM what functions are available and their
    # argument schemas, so it can request a tool call in its response.
    # Ollama supports this "tool calling" protocol for models that were
    # trained for it (llama3.2, qwen2.5, mistral-nemo, and others).
    return llm.bind_tools(ALL_TOOLS)


def _agent_node(state: AgentState) -> dict:
    """Calls the LLM with the current conversation. The LLM's response may
    contain `tool_calls` (a request to run one or more tools) or be a plain
    final answer."""
    llm = _build_llm()
    try:
        response = llm.invoke(state["messages"])
    except Exception as exc:  # noqa: BLE001 - surfaced to the UI layer
        raise RuntimeError(
            f"LLM call failed: {exc}. Make sure Ollama is running (`ollama serve`) "
            f"and that '{settings.llm_model}' has been pulled "
            f"(`ollama pull {settings.llm_model}`)."
        ) from exc
    return {"messages": [response]}


def _tools_node(state: AgentState) -> dict:
    """Executes every tool call requested by the last LLM message and
    returns the results as ToolMessages, which get appended to the
    conversation so the LLM can see them on its next turn."""
    last_message = state["messages"][-1]
    tool_by_name = {t.name: t for t in ALL_TOOLS}

    results = []
    for call in last_message.tool_calls:
        tool_fn = tool_by_name.get(call["name"])
        if tool_fn is None:
            content = f"TOOL_ERROR: Unknown tool requested: {call['name']}"
        else:
            try:
                content = tool_fn.invoke(call["args"])
            except Exception as exc:  # noqa: BLE001 - convert to a tool-visible error
                content = f"TOOL_ERROR: Tool '{call['name']}' raised an exception: {exc}"

        results.append(
            ToolMessage(content=str(content), tool_call_id=call["id"], name=call["name"])
        )

    return {"messages": results}


def _should_continue(state: AgentState) -> str:
    """Routing function: if the last LLM message requested tool calls, go
    run the tools node; otherwise the answer is final and the graph ends."""
    last_message = state["messages"][-1]
    if getattr(last_message, "tool_calls", None):
        return "tools"
    return END


def build_graph():
    """Constructs and compiles the LangGraph state graph."""
    graph = StateGraph(AgentState)
    graph.add_node("agent", _agent_node)
    graph.add_node("tools", _tools_node)

    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", _should_continue, {"tools": "tools", END: END})
    graph.add_edge("tools", "agent")

    return graph.compile()


def run_agent(user_query: str) -> dict:
    """High-level entrypoint used by the Streamlit UI.

    Returns a dict with:
        - "final_answer": the agent's final formatted text response.
        - "messages": the full raw message list (for debugging/trace display).
        - "tool_calls": a list of {"name", "args", "result"} for every tool
          actually invoked during this run (for the UI's "Tool Activity"
          panel).
    """
    if not user_query or not user_query.strip():
        raise ValueError("User query must not be empty.")

    app = build_graph()
    initial_state = {
        "messages": [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=user_query),
        ]
    }

    final_state = app.invoke(initial_state)
    messages = final_state["messages"]

    # Reconstruct which tools were called and with what result, by scanning
    # the message history for AIMessages with tool_calls followed by the
    # matching ToolMessages.
    tool_calls_made = []
    tool_results_by_id = {
        m.tool_call_id: m.content for m in messages if isinstance(m, ToolMessage)
    }
    for m in messages:
        calls = getattr(m, "tool_calls", None)
        if calls:
            for call in calls:
                tool_calls_made.append({
                    "name": call["name"],
                    "args": call["args"],
                    "result": tool_results_by_id.get(call["id"], ""),
                })

    final_answer = messages[-1].content

    return {
        "final_answer": final_answer,
        "messages": messages,
        "tool_calls": tool_calls_made,
    }
