"""
ingestion.py
============

WHAT: Builds the local Chroma vector database from the Markdown troubleshooting
      documents in data/troubleshooting/.
WHY:  Retrieval-Augmented Generation (RAG) needs documents converted into
      numeric vectors ("embeddings") ahead of time, stored in a searchable
      index (the vector database). Doing this once and persisting it to disk
      means the app does not have to re-embed every document on every user
      question (slow and expensive) — it only has to embed the new query.
WHERE: Called by ingest.py (the CLI entrypoint) and, indirectly, by
       retriever.py which loads the persisted database this module creates.

KEY CONCEPTS EXPLAINED INLINE:
- Document Loader: reads raw files off disk into a standard in-memory format.
- Text Splitter (chunking): breaks long documents into smaller overlapping
  pieces so retrieval can return focused, relevant sections instead of whole
  documents, and so each chunk fits within the LLM's context window.
- Embedding Model: converts text into a vector of numbers that captures
  semantic meaning, so "Wi-Fi connected but no internet" and "network is up
  but I can't browse" end up close together in vector space even though the
  wording differs.
- Vector Store (Chroma): a database specialized for storing embeddings and
  performing fast "nearest neighbor" similarity search over them.
"""

from __future__ import annotations

import os
import re
import sys

from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings

from src.config import settings

# Simple YAML-like front-matter parser for our KB docs. We keep this
# dependency-free (no PyYAML) since the front matter is a tiny, fixed format.
FRONT_MATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)


def _parse_front_matter(text: str) -> tuple[dict, str]:
    """Extracts the `key: value` front-matter block at the top of a KB
    document and returns (metadata_dict, remaining_body_text).

    WHY: Each KB document embeds structured metadata (document_id, title,
    category, severity, source). Attaching this metadata to every chunk lets
    the agent show accurate "Sources" and filter/reason about severity later,
    instead of only having raw unstructured text.
    """
    match = FRONT_MATTER_RE.match(text)
    if not match:
        return {}, text

    raw_block = match.group(1)
    metadata = {}
    for line in raw_block.strip().splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip()

    body = text[match.end():]
    return metadata, body


def load_documents(kb_dir: str):
    """Loads every .md/.txt file in kb_dir, splits off front-matter metadata,
    and returns a list of LangChain Document objects with metadata attached.
    """
    if not os.path.isdir(kb_dir):
        raise FileNotFoundError(
            f"Knowledge base directory not found: '{kb_dir}'. "
            "Create it and add .md/.txt troubleshooting documents before running ingest.py."
        )

    loader = DirectoryLoader(
        kb_dir,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
    )
    raw_docs = loader.load()

    if not raw_docs:
        raise FileNotFoundError(
            f"No .md documents found in '{kb_dir}'. Add troubleshooting documents first."
        )

    processed_docs = []
    for doc in raw_docs:
        metadata, body = _parse_front_matter(doc.page_content)
        filename = os.path.basename(doc.metadata.get("source", "unknown"))

        # Fill in sane defaults if a document is missing front matter fields.
        doc.metadata.update({
            "document_id": metadata.get("document_id", filename),
            "title": metadata.get("title", filename),
            "category": metadata.get("category", "general"),
            "severity": metadata.get("severity", "unknown"),
            "source": metadata.get("source", filename),
            "filename": filename,
        })
        doc.page_content = body.strip()
        processed_docs.append(doc)

    return processed_docs


def split_documents(documents, chunk_size: int = 800, chunk_overlap: int = 120):
    """Splits documents into overlapping chunks.

    WHY these numbers: troubleshooting sections (Symptoms, Diagnostic Steps,
    Resolution, etc.) are usually a few hundred characters each. 800 chars
    with 120 overlap keeps most single sections intact in one chunk while
    still allowing context to bleed across a section boundary, and keeps
    each chunk well within LLM context limits.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n## ", "\n# ", "\n\n", "\n", " ", ""],
    )
    chunks = splitter.split_documents(documents)

    # Preserve a stable per-chunk id in metadata for citation/debugging.
    for i, chunk in enumerate(chunks):
        chunk.metadata["chunk_id"] = f"{chunk.metadata.get('document_id', 'doc')}-{i}"

    return chunks


def build_vector_store(chunks, persist_directory: str, collection_name: str):
    """Embeds the given chunks and persists them into a local Chroma
    vector database directory. Running this again with the same
    persist_directory rebuilds the collection from scratch (idempotent).
    """
    # OllamaEmbeddings calls the local Ollama server to turn each chunk of
    # text into a vector. No API key is required, but Ollama must be
    # running (`ollama serve`) and the embedding model must be pulled
    # first (`ollama pull nomic-embed-text`).
    embeddings = OllamaEmbeddings(
        model=settings.embedding_model,
        base_url=settings.ollama_base_url,
    )

    try:
        vector_store = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            collection_name=collection_name,
            persist_directory=persist_directory,
        )
    except Exception as exc:  # noqa: BLE001 - surfaced to the CLI user directly
        raise RuntimeError(
            f"Failed to build the Chroma vector store: {exc}. Make sure Ollama "
            f"is running and '{settings.embedding_model}' has been pulled "
            f"(`ollama pull {settings.embedding_model}`)."
        ) from exc

    return vector_store


def run_ingestion() -> int:
    """Full ingestion pipeline entrypoint used by ingest.py.
    Returns the number of chunks written to the vector store.
    """
    print(f"[ingest] Loading documents from '{settings.knowledge_base_dir}' ...")
    documents = load_documents(settings.knowledge_base_dir)
    print(f"[ingest] Loaded {len(documents)} documents.")

    print("[ingest] Splitting documents into chunks ...")
    chunks = split_documents(documents)
    print(f"[ingest] Produced {len(chunks)} chunks.")

    print(
        f"[ingest] Creating embeddings with '{settings.embedding_model}' and "
        f"persisting to '{settings.chroma_persist_dir}' ..."
    )
    build_vector_store(
        chunks,
        persist_directory=settings.chroma_persist_dir,
        collection_name=settings.chroma_collection_name,
    )
    print("[ingest] Done. Vector store persisted to disk.")
    return len(chunks)


if __name__ == "__main__":
    try:
        run_ingestion()
    except Exception as exc:  # noqa: BLE001 - top-level CLI error handler
        print(f"[ingest] ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
