"""
tools.py
========

WHAT: Defines the callable "tools" the LangGraph agent can invoke.
WHY:  An "agentic" system is one where the LLM itself decides which action
      to take (retrieve knowledge? check a system's status? just answer?)
      rather than following a fixed, hard-coded script. LangChain/LangGraph
      implement this via "tool calling": we describe each tool (name,
      description, arguments) to the LLM, and the LLM's response can request
      that a specific tool be executed with specific arguments. Our code
      then actually runs that Python function and feeds the result back to
      the LLM.
WHERE: The tools defined here are bound to the LLM inside agent.py, and the
       agent graph executes them when the LLM requests them.

TOOLS IN THIS PROJECT:
1. search_troubleshooting_knowledge(query) - semantic search over the RAG
   knowledge base (wraps retriever.py).
2. check_system_status(system_name) - reads a local JSON file simulating
   real-time status of IT systems (vpn, email, authentication, network...).
   This is intentionally a mock/local tool for the MVP, but it is a REAL
   Python function call, and the LLM genuinely decides when to call it.
"""

from __future__ import annotations

import json
import os

from langchain_core.tools import tool

from src.config import settings
from src.retriever import search_knowledge_base, VectorStoreNotInitializedError


@tool
def search_troubleshooting_knowledge(query: str) -> str:
    """Search the internal IT troubleshooting knowledge base for documents
    relevant to the user's issue. Use this whenever the user describes a
    technical problem (network, software, hardware, account, etc.) so your
    answer is grounded in real documented procedures instead of guesses.

    Args:
        query: A concise description of the user's IT problem, e.g.
            "wifi connected but no internet" or "VPN keeps disconnecting".
    """
    try:
        results = search_knowledge_base(query)
    except VectorStoreNotInitializedError as exc:
        return f"TOOL_ERROR: {exc}"
    except ValueError as exc:
        return f"TOOL_ERROR: {exc}"
    except RuntimeError as exc:
        return f"TOOL_ERROR: {exc}"

    if not results:
        return "No relevant documents were found in the knowledge base for this query."

    # Format results as readable text blocks the LLM can reason over,
    # including metadata so the agent can cite sources accurately.
    blocks = []
    for r in results:
        blocks.append(
            f"[Source: {r['title']} | document_id={r['document_id']} | "
            f"category={r['category']} | severity={r['severity']} | "
            f"relevance_score={r['score']:.4f}]\n{r['content']}"
        )
    return "\n\n---\n\n".join(blocks)


@tool
def check_system_status(system_name: str) -> str:
    """Check the real-time operational status of a core IT system, such as
    'vpn', 'email', 'authentication', 'network', 'printing', or 'dns'. Use
    this when the user's issue could be caused by a known service-wide
    outage rather than a local device problem (e.g., VPN failures, login
    lockouts, email sync issues).

    Args:
        system_name: The name of the system to check, e.g. "vpn" or
            "authentication". Matching is case-insensitive.
    """
    path = settings.system_status_file
    if not os.path.isfile(path):
        return f"TOOL_ERROR: System status file not found at '{path}'."

    try:
        with open(path, "r", encoding="utf-8") as f:
            statuses = json.load(f)
    except json.JSONDecodeError as exc:
        return f"TOOL_ERROR: System status file is not valid JSON: {exc}"

    key = system_name.strip().lower()
    if key not in statuses:
        available = ", ".join(sorted(statuses.keys()))
        return (
            f"TOOL_ERROR: Unknown system '{system_name}'. "
            f"Available systems: {available}."
        )

    return f"System '{key}' status: {statuses[key]}"


# Tool list bound to the agent's LLM in agent.py.
ALL_TOOLS = [search_troubleshooting_knowledge, check_system_status]
