"""
retriever.py
============

WHAT: Loads the already-persisted Chroma vector database (built by
      ingest.py) and exposes a simple semantic-search function over it.
WHY:  Separating "load an existing index" (this file) from "build an index"
      (ingestion.py) means the Streamlit app can start up quickly by opening
      the database read-only, instead of re-embedding every document on
      every run.
WHERE: Used by tools.py to implement the search_troubleshooting_knowledge
       tool that the LangGraph agent calls.

KEY CONCEPT - Semantic Search:
Instead of exact keyword matching, the query is embedded into the same
vector space as the documents, and Chroma returns the chunks whose vectors
are closest (most similar in meaning) to the query vector. This is why a
query like "internet not working but wifi shows connected" can match a
document titled "Wi-Fi Connected But No Internet Access" even without
identical wording.
"""

from __future__ import annotations

import os

from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings

from src.config import settings

_vector_store: Chroma | None = None


class VectorStoreNotInitializedError(RuntimeError):
    """Raised when the Chroma persistence directory is missing or empty,
    meaning ingest.py has not been run yet."""


def _load_vector_store() -> Chroma:
    """Lazily loads and caches the Chroma vector store from disk."""
    global _vector_store
    if _vector_store is not None:
        return _vector_store

    persist_dir = settings.chroma_persist_dir
    if not os.path.isdir(persist_dir) or not os.listdir(persist_dir):
        raise VectorStoreNotInitializedError(
            f"Chroma database not found at '{persist_dir}'. "
            "Run `python ingest.py` first to build the knowledge base index."
        )

    # OllamaEmbeddings talks to the local Ollama server (no API key needed).
    # If Ollama is not running, or the embedding model has not been pulled
    # (`ollama pull nomic-embed-text`), the error surfaces the first time an
    # embedding is actually requested (see search_knowledge_base below).
    embeddings = OllamaEmbeddings(
        model=settings.embedding_model,
        base_url=settings.ollama_base_url,
    )

    _vector_store = Chroma(
        collection_name=settings.chroma_collection_name,
        embedding_function=embeddings,
        persist_directory=persist_dir,
    )
    return _vector_store


def search_knowledge_base(query: str, top_k: int | None = None) -> list[dict]:
    """Runs a semantic similarity search against the troubleshooting KB.

    Returns a list of dicts, each containing the retrieved chunk's text and
    metadata (document_id, title, category, severity, source), plus a
    similarity score (lower = more similar, since Chroma returns distance).

    Raises:
        VectorStoreNotInitializedError: if ingest.py has not been run yet.
        ValueError: if the query is empty.
    """
    if not query or not query.strip():
        raise ValueError("Query text must not be empty.")

    k = top_k or settings.retriever_top_k
    store = _load_vector_store()

    try:
        results = store.similarity_search_with_score(query, k=k)
    except Exception as exc:  # noqa: BLE001 - surfaced to caller/UI
        raise RuntimeError(
            f"Vector store search failed: {exc}. If this mentions a connection "
            f"error, make sure Ollama is running (`ollama serve`) and that the "
            f"'{settings.embedding_model}' model has been pulled "
            f"(`ollama pull {settings.embedding_model}`)."
        ) from exc

    formatted = []
    for doc, score in results:
        formatted.append({
            "content": doc.page_content,
            "document_id": doc.metadata.get("document_id"),
            "title": doc.metadata.get("title"),
            "category": doc.metadata.get("category"),
            "severity": doc.metadata.get("severity"),
            "source": doc.metadata.get("source"),
            "score": float(score),
        })
    return formatted
