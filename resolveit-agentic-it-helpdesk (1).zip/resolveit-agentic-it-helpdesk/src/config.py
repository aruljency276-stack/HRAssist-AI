"""
config.py
=========

WHAT: Centralized configuration loader for the whole application.
WHY:  Hard-coding model names and file paths throughout the codebase makes
      the project fragile and hard to change. Keeping all configuration in
      one place (loaded from environment variables via a .env file) means
      we can swap the local LLM, the embedding model, or the vector store
      location later by editing a single file (or just .env) instead of
      hunting through the codebase.
WHERE: Imported by ingestion.py, retriever.py, tools.py, agent.py, and app.py.

NOTE ON LOCAL MODELS: This MVP is configured to run entirely on your own
machine using Ollama (https://ollama.com) as the local model server. No
cloud API key, no per-token cost, and no internet connection is required
once the models are pulled. `OLLAMA_BASE_URL` points at the Ollama server
(the default `http://localhost:11434` is correct for a normal local
install); `LLM_MODEL` and `EMBEDDING_MODEL` name the two local models
Ollama must have already downloaded via `ollama pull <name>`.
"""

import os
from dataclasses import dataclass
from dotenv import load_dotenv

# Load variables from a local .env file into the process environment.
# This must happen before we read any os.environ values below.
load_dotenv()


def _get_env(key: str, default: str = "") -> str:
    """Small helper so every environment read goes through one place,
    making it easy to add logging/validation later if needed."""
    return os.environ.get(key, default)


@dataclass
class Settings:
    # --- Local model server (Ollama) ---
    ollama_base_url: str = _get_env("OLLAMA_BASE_URL", "http://localhost:11434")

    # --- LLM ---
    # Any Ollama model that supports tool/function calling works here.
    # llama3.2 and qwen2.5 are both known to support it.
    llm_model: str = _get_env("LLM_MODEL", "llama3.2")
    llm_temperature: float = float(_get_env("LLM_TEMPERATURE", "0.1"))

    # --- Embeddings ---
    # nomic-embed-text is a small, fast, locally-run embedding model.
    embedding_model: str = _get_env("EMBEDDING_MODEL", "nomic-embed-text")

    # --- Vector store ---
    chroma_persist_dir: str = _get_env("CHROMA_PERSIST_DIR", "chroma_db")
    chroma_collection_name: str = _get_env("CHROMA_COLLECTION_NAME", "it_troubleshooting")

    # --- Knowledge base ---
    knowledge_base_dir: str = _get_env("KNOWLEDGE_BASE_DIR", "data/troubleshooting")

    # --- Retrieval ---
    retriever_top_k: int = int(_get_env("RETRIEVER_TOP_K", "4"))

    # --- Mock system-status tool ---
    system_status_file: str = _get_env("SYSTEM_STATUS_FILE", "data/system_status.json")

    def validate_for_runtime(self) -> list[str]:
        """Returns a list of human-readable problems with the current
        configuration. Used at app startup to fail fast with a clear
        message instead of a confusing stack trace later.

        NOTE: We deliberately do NOT try to open a network connection to
        Ollama here (that would slow down every Streamlit rerun). Instead,
        a missing/unreachable Ollama server surfaces as a clear runtime
        error the first time the LLM or embeddings are actually called
        (see agent.py / retriever.py / ingestion.py)."""
        problems = []
        if not os.path.isdir(self.knowledge_base_dir):
            problems.append(
                f"Knowledge base directory '{self.knowledge_base_dir}' does not exist."
            )
        return problems


# Single shared settings instance imported across the project.
settings = Settings()
