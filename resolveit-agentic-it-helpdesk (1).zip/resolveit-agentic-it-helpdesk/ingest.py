"""
ingest.py
=========

WHAT: Command-line entrypoint to (re)build the local Chroma vector database
      from the documents in data/troubleshooting/.
WHY:  RAG requires embeddings to exist before the app can search them. This
      script is run manually/whenever the knowledge base changes, so the
      Streamlit app never has to regenerate embeddings on every question.

USAGE:
    python ingest.py
"""

import sys

from src.ingestion import run_ingestion

if __name__ == "__main__":
    try:
        num_chunks = run_ingestion()
        print(f"\nSuccess: {num_chunks} chunks embedded and stored in Chroma.")
    except Exception as exc:  # noqa: BLE001 - top-level CLI error handler
        print(f"\nIngestion failed: {exc}", file=sys.stderr)
        sys.exit(1)
