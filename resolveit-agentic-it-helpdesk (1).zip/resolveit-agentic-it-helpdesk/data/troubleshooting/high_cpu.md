---
document_id: KB-009
title: High CPU Usage
category: hardware
severity: medium
source: internal-demo-kb
---

# Issue
CPU usage is sustained at or near 100%, causing the system to become
unresponsive, hot, or loud, even when the user is not running demanding
applications.

# Symptoms
- Task Manager/Activity Monitor shows CPU usage consistently above 90%.
- Fans run at maximum speed continuously.
- Applications freeze or respond very slowly.
- Battery (on laptops) drains unusually fast.

# Possible Causes
1. A runaway or misbehaving process (browser tab, background updater) stuck
   in a loop.
2. Malware performing background activity (e.g., cryptomining, botnet agent).
3. A stuck Windows Update or antivirus definition update process.
4. Too many applications/services set to run simultaneously at startup.
5. Driver issue causing a background service to poll excessively.

# Diagnostic Steps
1. Open Task Manager/Activity Monitor, sort by CPU, and identify the top
   consuming process(es).
2. Note whether the process is a known, trusted application or unfamiliar.
3. Check if the spike correlates with a specific action (opening a browser
   tab, plugging in a device) or is constant regardless of activity.
4. Check Windows Update / antivirus history for an update currently in
   progress.
5. Run a malware scan if the offending process cannot be identified as
   legitimate.

# Resolution
1. End the specific runaway process/task if it is safe to do so, then monitor
   whether CPU usage returns to normal.
2. Let a legitimate stuck update (Windows Update, antivirus definitions)
   finish, or restart the machine to clear a stuck update process.
3. Update or reinstall the driver associated with a service consistently
   consuming CPU.
4. Reduce startup applications and background services that are not
   essential.
5. If malware is confirmed or suspected, isolate the device from the network
   and involve IT Security immediately.

# Escalation Criteria
Escalate to Security team immediately if malware or unauthorized/unknown
processes are suspected.

Escalate to Desktop Support if:
- High CPU persists after ending the offending process and rebooting.
- The issue is linked to a specific hardware component (e.g., failing fan
  causing thermal throttling that in turn worsens performance).

# Severity
Medium to High depending on cause — routine background process is Medium;
suspected malware is High and time-sensitive.
