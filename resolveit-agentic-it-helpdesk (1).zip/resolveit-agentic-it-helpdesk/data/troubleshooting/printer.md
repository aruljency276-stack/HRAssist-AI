---
document_id: KB-005
title: Printer Not Responding
category: hardware
severity: low
source: internal-demo-kb
---

# Issue
A print job is sent but the printer does not respond: nothing prints, the job
stays queued, or an error appears in the print queue.

# Symptoms
- Print job stuck in "Pending" or "Error" state in the print queue.
- Printer shows as "Offline" in the operating system's device list.
- Printer's physical display shows an error code, paper jam, or is powered off.
- Other users on the same network printer are also unable to print.

# Possible Causes
1. Printer is powered off, out of paper/toner, or has a paper jam.
2. Printer is offline on the network (lost Wi-Fi/Ethernet connection).
3. Print spooler service on the local machine is stuck or crashed.
4. Outdated or corrupted printer driver.
5. Printer's IP address changed (common with DHCP) and the saved printer
   connection is now pointing to the wrong address.

# Diagnostic Steps
1. Check the printer's physical display/light for error codes, paper jams, or
   low supplies.
2. Confirm the printer shows "Ready"/"Online" rather than "Offline" in
   Settings → Printers & Scanners.
3. Try printing a test page directly from the printer's own menu (bypassing the
   computer) to confirm hardware is functional.
4. Check the print spooler service status (Windows: `services.msc` → "Print
   Spooler").
5. Ping the printer's IP address from the affected computer to confirm network
   reachability.

# Resolution
1. Clear physical issues: add paper/toner, clear jams, power cycle the printer.
2. Restart the Print Spooler service, then clear stuck jobs from the queue.
3. If the printer's IP address changed, remove and re-add the printer using the
   current IP or hostname.
4. Update or reinstall the printer driver from the manufacturer's latest package.
5. If multiple users are affected, check the printer's network connection and
   restart the print server if the environment uses one.

# Escalation Criteria
Escalate to Desktop Support/Facilities if:
- The printer hardware itself reports a persistent fault code after power cycling.
- Multiple users across the floor cannot reach the shared printer, indicating a
  network or print-server issue rather than a single workstation problem.
- A hardware technician visit is required (e.g., internal component failure).

# Severity
Low — typically a single device/user impact with a clear workaround (alternate
printer) available.
