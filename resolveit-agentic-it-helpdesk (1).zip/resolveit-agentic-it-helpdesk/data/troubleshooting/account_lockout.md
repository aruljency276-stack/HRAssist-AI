---
document_id: KB-007
title: Password / Account Lockout
category: authentication
severity: high
source: internal-demo-kb
---

# Issue
The user cannot log into their corporate account (workstation, email, or SSO
portal), receiving a lockout or invalid credential message.

# Symptoms
- Login screen shows "Account is locked" or "Too many failed attempts."
- Correct password is rejected repeatedly.
- SSO portal redirects back to login without a clear error.
- User was recently prompted to change their password and may be using the
  old one.

# Possible Causes
1. Too many incorrect password attempts triggered an automatic lockout policy.
2. Password recently expired or was changed and a cached credential (e.g., on
   a phone or saved app) is retrying the old password, causing repeated lockouts.
3. Authentication service (identity provider) outage or degradation.
4. Account flagged by security systems due to suspicious login activity.
5. Time synchronization issue on the device affecting MFA token validity.

# Diagnostic Steps
1. Confirm the exact error message and whether it mentions "locked," "expired,"
   or "invalid credentials."
2. Check the system-status tool for the "authentication" service to rule out a
   broader identity provider outage.
3. Ask whether the password was recently changed and whether other
   devices/apps (mobile mail, mapped drives) still have the old password saved.
4. Verify the device's clock is synced correctly (affects time-based MFA codes).

# Resolution
1. If the system-status tool reports authentication as degraded, inform the
   user this is a known service-wide issue and provide an ETA if available;
   no local fix will help until it is resolved.
2. If the account is locked from repeated bad attempts, unlock it via the
   identity management console (or self-service password reset if enabled)
   after verifying identity.
3. Update saved credentials on all devices/apps to the new password to stop
   further lockout attempts (a common recurring cause).
4. Resync the device clock if MFA codes are being rejected.
5. If suspicious activity flagged the account, involve IT Security before
   unlocking.

# Escalation Criteria
Escalate to Identity/Security team immediately if:
- The system-status tool shows the authentication service itself is degraded
  or down.
- There are signs of a compromised account (logins from unexpected locations).
- Standard unlock/reset procedures do not restore access.

# Severity
High — blocks all work for the affected user and may indicate a security event.
