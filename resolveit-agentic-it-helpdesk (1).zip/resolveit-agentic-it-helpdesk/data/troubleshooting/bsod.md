---
document_id: KB-008
title: Blue Screen / System Crash
category: hardware
severity: high
source: internal-demo-kb
---

# Issue
The computer unexpectedly crashes to a blue screen (Windows) or kernel panic
(Mac/Linux), then restarts, sometimes repeatedly.

# Symptoms
- Blue Screen of Death (BSOD) with a stop code (e.g., MEMORY_MANAGEMENT,
  IRQL_NOT_LESS_OR_EQUAL, DRIVER_IRQL_NOT_LESS_OR_EQUAL).
- System restarts automatically without a visible error (crash logged in
  Event Viewer only).
- Crashes correlate with a specific action: waking from sleep, running a
  specific application, or connecting a peripheral.
- Repeated crash loop preventing normal use of the machine.

# Possible Causes
1. Faulty or incompatible device driver (especially graphics, network, or
   storage drivers) recently updated.
2. Failing RAM module or storage drive (disk errors).
3. Overheating due to blocked vents or failed cooling fan.
4. Corrupted system files or a botched Windows update.
5. Incompatible or conflicting third-party security software.

# Diagnostic Steps
1. Note the exact stop code / error message shown on the blue screen, if any.
2. Check Windows Event Viewer (Windows Logs → System) for the corresponding
   Kernel-Power or BugCheck event and the driver referenced.
3. Identify whether the crash started after a recent driver, OS, or software
   update.
4. Run built-in memory diagnostics (Windows Memory Diagnostic) and disk health
   checks (`chkdsk`, S.M.A.R.T. status).
5. Check for excessive heat (fan noise, hot chassis) that could indicate a
   cooling problem.

# Resolution
1. If a specific driver is implicated in Event Viewer, roll back or update
   that driver to the latest stable version.
2. If a recent update correlates with the crashes, uninstall the update or
   use System Restore to a point before the update.
3. Run memory and disk diagnostics; replace failing hardware components as
   needed (RAM, drive).
4. Ensure vents are unobstructed and consider a professional cleaning if
   overheating is confirmed.
5. Reinstall or repair the OS as a last resort if corruption is confirmed and
   no single driver/hardware cause is found.

# Escalation Criteria
Escalate to Desktop Support/Hardware team immediately if:
- Memory or disk diagnostics report hardware failures.
- The crash loop prevents the user from booting into the OS at all.
- Multiple machines with the same hardware/driver combination are affected
  after a recent rollout (possible fleet-wide driver issue).

# Severity
High — can cause data loss and completely blocks the user until resolved.
