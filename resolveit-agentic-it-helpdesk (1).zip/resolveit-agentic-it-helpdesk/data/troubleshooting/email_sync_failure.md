---
document_id: KB-012
title: Email Client Synchronization Failure
category: software
severity: medium
source: internal-demo-kb
---

# Issue
The email client (desktop or mobile) stops sending/receiving new mail, shows a
sync error, or repeatedly prompts for credentials.

# Symptoms
- Email client shows "Disconnected," "Sync error," or a spinning sync icon
  that never completes.
- Repeated password/credential prompts even after entering correct
  credentials.
- New emails appear on the webmail portal but not in the desktop/mobile
  client.
- Sent emails remain stuck in the Outbox.

# Possible Causes
1. Expired authentication token or password change not yet updated in the
   client.
2. Mailbox storage quota exceeded, blocking new mail delivery/sync.
3. Email server/service outage or degradation.
4. Corrupted local mail data file (e.g., OST/PST cache) on desktop clients.
5. Incorrect server settings after a migration (e.g., IMAP/Exchange endpoint
   changed).
6. Network connectivity or VPN issue if the mail server requires internal
   network access.

# Diagnostic Steps
1. Confirm whether webmail (browser-based access) works normally — if so, the
   issue is client-side, not server-side.
2. Check the system-status tool for the "email" service to rule out a
   known outage.
3. Re-enter credentials in the client and confirm no old saved password is
   cached elsewhere (e.g., Credential Manager).
4. Check mailbox quota/storage usage.
5. Review the client's connection/account settings for the correct
   server/protocol configuration.

# Resolution
1. If the system-status tool reports the email service as degraded, inform
   the user this is a known outage and no local fix is needed until service
   is restored.
2. Update saved credentials in the client and in the OS credential manager.
3. If storage quota is exceeded, archive or delete old mail to free space, or
   request a quota increase per policy.
4. Rebuild/reset the local mail cache file (e.g., create a new Outlook
   profile) if the local data file is corrupted.
5. Correct server/account settings if they are found to be outdated after a
   migration.

# Escalation Criteria
Escalate to Messaging/Infrastructure team if:
- The system-status tool shows the email service itself is degraded or down.
- Multiple users are affected simultaneously, suggesting a server-side issue.
- Mail data corruption recurs after a profile rebuild.

# Severity
Medium — disrupts communication but usually has a temporary workaround via
webmail.
