---
document_id: KB-001
title: Wi-Fi Connected But No Internet Access
category: network
severity: medium
source: internal-demo-kb
---

# Issue
User's device shows Wi-Fi as "Connected" (sometimes with a warning icon), but no
websites or online services load.

# Symptoms
- Wi-Fi icon shows connected, sometimes with an exclamation mark or "no internet" label.
- Browser shows "DNS_PROBE_FINISHED_NO_INTERNET" or a generic connection error.
- Some devices on the same network work fine; others do not.
- Wired (Ethernet) connection on the same device works normally.

# Possible Causes
1. Router has lost its upstream internet connection (ISP outage) even though the
   local Wi-Fi network itself is still up.
2. The device obtained an invalid or duplicate IP address (APIPA address in the
   169.254.x.x range).
3. DNS server assigned by the router is unreachable.
4. Captive portal (common in hotel/office guest Wi-Fi) has not been completed.
5. Router firmware issue or the router needs a reboot.
6. Too many devices connected, exhausting DHCP leases.

# Diagnostic Steps
1. Check whether other devices on the same Wi-Fi network can reach the internet.
2. Run `ipconfig /all` (Windows) or `ifconfig`/`ip a` (Mac/Linux) and confirm the
   assigned IP address is not in the 169.254.x.x range.
3. Try to ping the router's gateway IP address (e.g., 192.168.1.1).
4. Try to ping a public IP address such as 8.8.8.8 to isolate DNS vs. connectivity.
5. Open a browser and check for a captive portal login page.
6. Check the router/modem status lights for an internet/WAN outage indicator.

# Resolution
1. If the gateway ping fails: restart the router/modem (power cycle, wait 30 seconds).
2. If the IP address is in the 169.254.x.x range: release and renew the IP
   (`ipconfig /release` then `ipconfig /renew` on Windows).
3. If ping to the gateway works but ping to 8.8.8.8 fails: the issue is likely an
   ISP outage upstream of the router; contact the ISP.
4. If a captive portal is present: open a browser and complete the login/acceptance
   page.
5. As a general first step, reconnect to the Wi-Fi network or forget and rejoin it.

# Escalation Criteria
Escalate to Network Operations if:
- The router reboot does not restore connectivity within 10 minutes.
- Multiple users/devices across the same office/floor are affected simultaneously.
- ISP status page confirms a regional outage lasting more than 30 minutes.

# Severity
Medium — affects individual productivity but is usually resolved without data loss.
