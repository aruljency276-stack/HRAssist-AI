---
document_id: KB-006
title: VPN Connection Failure
category: network
severity: high
source: internal-demo-kb
---

# Issue
The corporate VPN client fails to connect, disconnects immediately after
connecting, or connects but does not provide access to internal resources.

# Symptoms
- VPN client shows "Connection failed" or times out during the handshake.
- VPN connects successfully but drops within seconds or minutes.
- VPN shows "Connected" but internal resources (file shares, intranet) are
  unreachable.
- Error codes such as authentication failure or "unable to reach server."

# Possible Causes
1. Expired or incorrect VPN credentials, or MFA token not accepted.
2. VPN gateway/server-side outage or maintenance window.
3. Local firewall or antivirus blocking the VPN client's ports/protocol.
4. Underlying internet connection is unstable (see Wi-Fi/DNS docs).
5. Outdated VPN client software incompatible with the current gateway version.
6. Split-tunneling/routing misconfiguration causing internal resources to be
   unreachable even though the tunnel is up.

# Diagnostic Steps
1. Confirm the underlying internet connection is stable (test a non-VPN website).
2. Verify credentials and MFA prompt are being received and accepted correctly.
3. Check the VPN client version against the minimum supported version.
4. Review VPN client logs for the specific error code at time of failure.
5. Use the system-status check for the "vpn" service to confirm whether there is
   a known service-wide outage before deep local troubleshooting.

# Resolution
1. If the system status tool reports the VPN service as degraded or down,
   inform the user this is a known service-wide issue — no local fix needed,
   monitor for restoration.
2. If credentials/MFA are the issue, reset the password or resync the MFA app,
   following identity-team procedures.
3. Restart the VPN client and, if needed, the local network adapter.
4. Temporarily disable third-party firewall/antivirus to test whether it is
   blocking the VPN (re-enable immediately after testing).
5. Update the VPN client to the latest approved version.
6. If connected but internal resources are unreachable, confirm split-tunnel
   routes with the network team.

# Escalation Criteria
Escalate to Network/Security team immediately if:
- The system-status tool or monitoring shows the VPN service itself is degraded
  or down for multiple users.
- Authentication failures may indicate a compromised account (repeated lockouts).
- The issue persists after client reinstall and credential verification.

# Severity
High — blocks access to internal systems and can affect many remote employees
simultaneously.
