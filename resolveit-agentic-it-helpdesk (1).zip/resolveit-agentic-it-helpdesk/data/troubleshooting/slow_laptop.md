---
document_id: KB-004
title: Laptop Running Slowly
category: hardware
severity: low
source: internal-demo-kb
---

# Issue
The laptop is noticeably slower than usual: applications take longer to open,
the system lags when switching windows, or the fan runs constantly.

# Symptoms
- General sluggishness across most applications, not just one.
- Fan noise is loud/continuous even during light use.
- Task Manager shows sustained high CPU, memory, or disk usage.
- Boot time has increased significantly compared to baseline.

# Possible Causes
1. Too many startup programs launching at boot.
2. Insufficient free disk space (especially on the system/boot drive).
3. Background updates, antivirus scans, or sync clients (OneDrive, Dropbox)
   consuming resources.
4. Too many browser tabs/extensions consuming memory.
5. Malware or unwanted background processes.
6. Aging hardware (spinning HDD instead of SSD, low RAM) reaching its limits.

# Diagnostic Steps
1. Open Task Manager (Ctrl+Shift+Esc) and sort by CPU, then Memory, then Disk to
   identify the top consuming process.
2. Check available free disk space on the system drive (recommend keeping at
   least 15-20% free).
3. Review Startup tab in Task Manager for unnecessary auto-launching apps.
4. Check whether a scheduled antivirus scan or OS update is currently running.
5. Confirm total installed RAM and whether usage is consistently near the limit.

# Resolution
1. Disable unnecessary startup applications (Task Manager → Startup tab → Disable).
2. Free up disk space: clear temporary files, empty Recycle Bin, uninstall unused
   applications, use Disk Cleanup.
3. Pause or reschedule cloud sync clients and antivirus scans to off-peak hours
   where policy allows.
4. Close unused browser tabs and disable unused extensions.
5. Run a full malware/antivirus scan if no other cause is found.
6. If hardware is the bottleneck (e.g., HDD, <8GB RAM) and within refresh policy,
   recommend a hardware upgrade or replacement request.

# Escalation Criteria
Escalate to Desktop Support/Asset Management if:
- High resource usage is caused by an unidentified or suspicious process
  (possible malware) — escalate to Security immediately in that case.
- The device is past its refresh cycle and hardware limitations cannot be
  resolved through software cleanup.
- Performance issues persist after all standard remediation steps.

# Severity
Low — impacts productivity but rarely a full outage.
