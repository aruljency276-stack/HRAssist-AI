---
document_id: KB-002
title: DNS Resolution Failure
category: network
severity: medium
source: internal-demo-kb
---

# Issue
Applications and browsers fail to resolve domain names to IP addresses, even
though the underlying network connection is otherwise working.

# Symptoms
- Browser error: "This site can't be reached" / "DNS_PROBE_FINISHED_NXDOMAIN".
- Pinging a domain name fails, but pinging a raw IP address (e.g., 8.8.8.8) works.
- Some internal apps that use IP addresses directly still function.
- Intermittent failures: some domains resolve, others do not.

# Possible Causes
1. The configured DNS server (from the router or corporate DHCP) is unreachable
   or overloaded.
2. Local DNS cache contains stale or corrupted entries.
3. VPN client is redirecting DNS queries to an unreachable internal DNS server.
4. Misconfigured static DNS settings on the device.
5. Corporate DNS filtering/security service (e.g., web filter) blocking resolution.

# Diagnostic Steps
1. Run `nslookup example.com` and check whether it returns a valid IP or times out.
2. Try `nslookup example.com 8.8.8.8` to test against a known-good public DNS server.
3. Check current DNS server configuration (`ipconfig /all` on Windows, `scutil --dns`
   on Mac, `resolvectl status` on Linux).
4. Flush the local DNS cache and retest.
5. Confirm whether the issue occurs both on and off VPN.

# Resolution
1. Flush DNS cache: `ipconfig /flushdns` (Windows), `sudo dscacheutil -flushcache`
   (Mac), `sudo resolvectl flush-caches` (Linux).
2. If the corporate DNS server is unreachable, temporarily switch to a public
   DNS resolver (e.g., 1.1.1.1 or 8.8.8.8) for testing purposes only.
3. If the issue only occurs on VPN, verify VPN DNS push settings with the network
   team — do not permanently override corporate DNS without approval.
4. Restart the DNS client service (Windows: `services.msc` → "DNS Client" → Restart).
5. If a specific security/web filter is blocking legitimate domains, request a
   allow-list exception from IT Security.

# Escalation Criteria
Escalate to Network/Infrastructure team if:
- The corporate DNS server itself is confirmed down for multiple users.
- Public DNS resolves the domain but corporate DNS does not, indicating a
  server-side or filtering issue.
- The problem persists after cache flush and DNS server change.

# Severity
Medium — often quick to work around, but can indicate a wider infrastructure issue.
