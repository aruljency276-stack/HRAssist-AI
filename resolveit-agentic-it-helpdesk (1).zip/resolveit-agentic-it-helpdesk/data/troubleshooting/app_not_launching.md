---
document_id: KB-003
title: Windows Application Not Launching
category: software
severity: medium
source: internal-demo-kb
---

# Issue
A previously working desktop application fails to open. The user may see no
response when clicking the icon, a brief flash of a window that closes, or an
error dialog.

# Symptoms
- Double-clicking the icon does nothing, or the icon flashes and disappears.
- Error message such as "Application failed to start because [X] was not found."
- The application appears briefly in Task Manager and then disappears.
- Other applications on the same machine work normally.

# Possible Causes
1. Corrupted application installation or missing/corrupted DLL dependencies.
2. Conflicting background process or a previous instance stuck in memory.
3. Insufficient user permissions on the install directory or registry keys.
4. Outdated or incompatible graphics/driver stack for GPU-accelerated apps.
5. Antivirus/endpoint protection quarantining or blocking the executable.
6. Corrupted user profile or application settings/cache.

# Diagnostic Steps
1. Check Task Manager for a stuck/zombie process with the same executable name
   and end it if present.
2. Review the Windows Event Viewer (Application log) for the specific error
   matching the crash time.
3. Try launching the application as Administrator.
4. Check whether antivirus/EDR quarantined the executable recently.
5. Try launching from a new local user profile to rule out profile corruption.

# Resolution
1. End any stuck background processes for the application via Task Manager, then
   relaunch.
2. If Event Viewer shows a missing dependency, reinstall the application or repair
   it via "Apps & Features" → Modify/Repair.
3. If antivirus quarantined the file, restore it from quarantine and add an
   exclusion if confirmed safe by IT Security.
4. Clear the application's local cache/config folder (back up first) and relaunch.
5. Update graphics drivers if the application is GPU-accelerated and crashes on
   startup.
6. As a last resort, uninstall and reinstall the application using the latest
   approved installer from the software catalog.

# Escalation Criteria
Escalate to Desktop Support/Engineering if:
- The application fails identically on a freshly created local user profile.
- Reinstallation does not resolve the issue.
- The crash is linked to a recent OS or security patch affecting multiple users.

# Severity
Medium — blocks a single application but usually has a workaround (web version,
alternate tool) while resolved.
