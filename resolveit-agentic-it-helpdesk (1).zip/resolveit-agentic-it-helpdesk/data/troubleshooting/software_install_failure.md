---
document_id: KB-011
title: Software Installation Failure
category: software
severity: low
source: internal-demo-kb
---

# Issue
An application installer fails partway through, exits with an error code, or
completes but the application does not work correctly afterward.

# Symptoms
- Installer shows an error dialog with a code (e.g., exit code 1603 for MSI
  installers).
- Installation progress bar freezes or the installer silently closes.
- "Insufficient permissions" or "Access denied" message during install.
- Installer completes, but the application fails to launch (see the
  application-not-launching document for that specific case).

# Possible Causes
1. Insufficient user permissions to write to Program Files or the registry.
2. Insufficient disk space for the installation.
3. A previous failed/partial installation left the system in an inconsistent
   state.
4. Antivirus/endpoint protection blocking the installer.
5. Installer package itself is corrupted (incomplete download).
6. Conflicting older version of the same software not fully removed.

# Diagnostic Steps
1. Note the exact error code or message shown by the installer.
2. Confirm the user has local administrator rights required for installation
   (or that the approved software catalog/deployment tool is being used).
3. Check available free disk space against the installer's minimum
   requirement.
4. Check whether antivirus/EDR logged a block or quarantine event during
   install.
5. Verify the installer file's integrity (re-download from the approved
   source if size/hash looks wrong).

# Resolution
1. Re-run the installer with administrator rights, or request installation via
   the approved software deployment/self-service catalog.
2. Free up disk space if the installer reported insufficient space.
3. Fully uninstall any previous/partial version (including leftover folders)
   before reinstalling.
4. Temporarily whitelist the installer in antivirus/EDR if confirmed safe by
   IT Security, then retry.
5. Re-download the installer from the official/approved source in case the
   original file was corrupted.

# Escalation Criteria
Escalate to Software Deployment/Engineering team if:
- The installer fails identically after all standard remediation steps.
- The failure appears linked to a packaging or deployment tool issue
  affecting multiple users (e.g., a broken package in the software catalog).

# Severity
Low — typically affects a single user and has a workaround (alternate
software or delayed install) while resolved.
