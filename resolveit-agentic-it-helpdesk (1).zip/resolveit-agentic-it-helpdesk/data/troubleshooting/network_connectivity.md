---
document_id: KB-010
title: General Network Connectivity Problems
category: network
severity: medium
source: internal-demo-kb
---

# Issue
The device cannot reach the network at all (no Wi-Fi or Ethernet connectivity),
as distinct from being connected but lacking internet (see the Wi-Fi document)
or having only DNS problems (see the DNS document).

# Symptoms
- No Wi-Fi networks visible in the list, or Ethernet shows "No connection."
- Network adapter shows a yellow warning icon or "Disabled" status.
- Intermittent total connectivity loss across both Wi-Fi and Ethernet.
- Airplane mode inadvertently enabled.

# Possible Causes
1. Network adapter disabled or in a faulty driver state.
2. Physical cable or Wi-Fi hardware issue (e.g., damaged cable, hardware
   Wi-Fi switch turned off).
3. Airplane mode enabled by accident.
4. Corrupted network adapter driver following an OS update.
5. Router/switch port failure on the infrastructure side.

# Diagnostic Steps
1. Confirm airplane mode is off and the physical Wi-Fi switch (if present) is
   enabled.
2. Check Device Manager / network settings for the adapter's status (enabled,
   disabled, error).
3. Try a different Ethernet cable/port or a different Wi-Fi network to isolate
   hardware vs. environment.
4. Review Event Viewer for network adapter driver errors around the time
   connectivity was lost.
5. Test the device on a known-good network to rule out a device-side issue
   entirely.

# Resolution
1. Re-enable the network adapter if disabled, or disable/re-enable it to reset
   its state.
2. Update or roll back the network adapter driver if a recent update
   correlates with the issue.
3. Replace a damaged Ethernet cable or try a different switch port.
4. Turn off airplane mode / re-enable the hardware Wi-Fi switch.
5. Reset network settings (Windows: Settings → Network → Network Reset) as a
   broader fix if individual steps do not resolve it.

# Escalation Criteria
Escalate to Network Infrastructure team if:
- The issue reproduces on multiple known-good networks, pointing to a
  hardware fault requiring device replacement.
- A specific switch port or office area is confirmed to be affecting multiple
  users.

# Severity
Medium — blocks all network-dependent work for the affected user until
resolved.
