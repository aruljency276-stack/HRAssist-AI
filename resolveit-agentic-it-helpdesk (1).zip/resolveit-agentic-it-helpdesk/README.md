# ResolveIT — Agentic AI IT Helpdesk

**RAG-Powered Troubleshooting, Defect Resolution & Root Cause Analysis Agent**

ResolveIT is a portfolio-grade MVP of an internal IT helpdesk assistant. It
answers IT troubleshooting questions by retrieving relevant documentation
from a local knowledge base (Retrieval-Augmented Generation) and by letting
an AI agent decide, on its own, when it needs to call a tool — such as
checking a system's live status — before producing a grounded answer.

The entire system runs **locally**, using [Ollama](https://ollama.com) to
serve both the LLM and the embedding model. There is no cloud API key, no
per-query cost, and no dependency on an internet connection at runtime.

## 1. Project Description

Non-technical users often struggle to describe or resolve common IT
problems (Wi-Fi issues, VPN failures, slow laptops, printer errors, account
lockouts, and so on), and a first-line human helpdesk agent spends a large
share of their time repeating the same documented troubleshooting steps.
ResolveIT demonstrates how a small, locally-run agentic AI system can act as
a first line of triage: it searches a curated knowledge base for the
relevant procedure, decides whether it needs additional live information
(via a tool), and returns a structured, grounded troubleshooting response —
while being explicit about what it doesn't know.

## 2. Problem Statement

Users need instant, consistent, and technically accurate troubleshooting
guidance for common IT issues, but:
- Documentation is scattered and users don't know which article applies.
- A plain LLM chatbot can hallucinate plausible-sounding but wrong fixes.
- There is no way to check whether a problem is local (the user's device)
  or systemic (a known outage) without a human checking a status dashboard.

## 3. Solution

ResolveIT combines two AI engineering techniques:

1. **Retrieval-Augmented Generation (RAG)** — the user's question is used
   to semantically search a local vector database of troubleshooting
   documents, so the LLM's answer is grounded in real, retrieved text
   instead of its own (possibly wrong) general knowledge.
2. **Agentic tool calling** — a LangGraph agent decides, per question,
   whether it needs to search the knowledge base, check a simulated
   system-status feed, both, or neither, rather than following a fixed
   script.

## 4. Architecture

```mermaid
flowchart TD
    U[User Query] --> A[LangGraph Agent Node<br/>LLM: llama3.2 via Ollama]
    A -->|decides a tool is needed| T{Which tool?}
    T -->|knowledge lookup| R[search_troubleshooting_knowledge<br/>Chroma retriever]
    T -->|status check| S[check_system_status<br/>local JSON mock]
    R --> A
    S --> A
    A -->|no more tools needed| F[Grounded Troubleshooting Response]
```

## 5. Key Features

- Local Retrieval-Augmented Generation over a 12-document IT troubleshooting
  knowledge base (Markdown, with structured front-matter metadata).
- Local Chroma vector database, persisted to disk (`chroma_db/`), built once
  via `python ingest.py` and reused across app runs (no re-embedding per
  question).
- A LangGraph agent with two real, LLM-invoked tools:
  - `search_troubleshooting_knowledge(query)` — semantic search over the KB.
  - `check_system_status(system_name)` — reads a local JSON file simulating
    live status for vpn/email/authentication/network.
- A fixed, structured response format (Issue / Probable Root Cause /
  Recommended Troubleshooting / Resolution / Tool-System Status /
  Escalation / Sources) so every answer is auditable.
- A Streamlit chat UI showing chat history, retrieved sources, and tool
  activity for each turn.
- Runs entirely offline once the two Ollama models are pulled — no API key,
  no billing, no external network calls.

## 6. Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.11+ |
| Orchestration | LangChain, LangGraph |
| LLM (local) | Ollama — `llama3.2` (tool-calling capable) |
| Embeddings (local) | Ollama — `nomic-embed-text` |
| Vector database | Chroma (local, on-disk persistence) |
| UI | Streamlit |
| Config | python-dotenv |

## 7. RAG Pipeline

```
Troubleshooting Documents (data/troubleshooting/*.md)
        |
        v
Document Loading            (src/ingestion.py — DirectoryLoader/TextLoader)
        |
        v
Text Splitting               (RecursiveCharacterTextSplitter, ~800 chars/chunk)
        |
        v
Embeddings                   (Ollama: nomic-embed-text)
        |
        v
Chroma Vector Database       (persisted to chroma_db/)
        |
        v
Semantic Retrieval           (src/retriever.py — similarity_search_with_score)
        |
        v
Retriever Tool                (src/tools.py — search_troubleshooting_knowledge)
        |
        v
LangGraph Agent               (src/agent.py)
        |
        v
LLM (Ollama: llama3.2)
        |
        v
Grounded Troubleshooting Response
```

## 8. Agent Workflow

```
User Query
    |
    v
Agent (LLM decides)
    |
    v
Determine whether retrieval/tool is required
    |
    v
Retriever Tool  /  System Status Tool
    |
    v
Retrieved Context + Tool Result
    |
    v
Final Structured Response
```

## 9. Tools

| Tool | Purpose | Notes |
|---|---|---|
| `search_troubleshooting_knowledge(query)` | Semantic search over the local Chroma KB | Wraps `src/retriever.py`; returns formatted chunks with title/category/severity/score, or a clear "no results" / error string. |
| `check_system_status(system_name)` | Reads simulated live status of a core IT system | Reads `data/system_status.json`; intentionally a local mock for the MVP — the important part is that the LLM genuinely decides when to call it. |

## 10. Project Structure

```
resolveit-agentic-it-helpdesk/
│
├── app.py                     # Streamlit UI
├── ingest.py                  # CLI: build/rebuild the Chroma index
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
│
├── data/
│   ├── system_status.json     # Mock live status for check_system_status
│   └── troubleshooting/       # 12 knowledge-base documents (.md)
│
├── chroma_db/                 # Persisted local vector database (git-ignored)
│
├── src/
│   ├── config.py               # Centralized settings (Ollama, Chroma, KB paths)
│   ├── ingestion.py             # Load -> split -> embed -> persist
│   ├── retriever.py             # Load persisted DB + semantic search
│   ├── tools.py                 # The two agent tools
│   ├── agent.py                  # LangGraph state graph (agent + tools nodes)
│   └── prompts.py                # System prompt / output-format contract
│
└── tests/
    ├── test_retrieval.py
    └── test_tools.py
```

## 11. Installation

**Prerequisites:** Python 3.11+, and [Ollama](https://ollama.com) installed
and running on your machine.

```bash
# 1. Clone the repository
git clone https://github.com/KARTHIKAKRISHNA123/resolve-it.git
cd resolve-it

# 2. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install Python dependencies
pip install -r requirements.txt

# 4. Pull the local models (one-time download, requires internet)
ollama pull llama3.2
ollama pull nomic-embed-text

# 5. Make sure the Ollama server is running
ollama serve                    # if it isn't already running as a service
```

## 12. Environment Variables

Copy `.env.example` to `.env` if you want to override any default (model
name, Ollama host, chunking, etc.). The defaults work out of the box for a
standard local Ollama install, so this step is optional.

```bash
cp .env.example .env
```

## 13. Ingest the Knowledge Base

Before running the app for the first time (and any time you add or edit a
document in `data/troubleshooting/`), rebuild the vector index:

```bash
python ingest.py
```

This loads every `.md` file, splits it into chunks, embeds each chunk with
`nomic-embed-text`, and persists the result into `chroma_db/`.

## 14. Run the Application

```bash
streamlit run app.py
```

Then open the URL Streamlit prints (typically `http://localhost:8501`).

## 15. Example Questions to Try

1. "My Wi-Fi says connected but I cannot open websites."
2. "The VPN is not connecting."
3. "My printer is not responding."
4. "My laptop is extremely slow."
5. "I cannot log into my account."
6. "My email is not synchronizing."
7. "Why can't I install this application?"
8. "Our authentication system seems to be down."

## 16. Screenshots

_Add screenshots of the running app here, e.g.:_
- Figure 1 — Application interface
- Figure 2 — Retrieved source documents panel
- Figure 3 — Tool activity panel (e.g. `check_system_status` being called)
- Figure 4 — A final structured troubleshooting response

## 17. Limitations

- This is an MVP, **not production-ready**: no authentication, no real
  ticketing-system integration, no persistence of chat history across
  sessions, no automated evaluation benchmark.
- `check_system_status` reads a static local JSON file — it is a
  deliberate mock, not a real monitoring integration.
- Answer quality depends on the local model chosen; a small model like
  `llama3.2` (3B) can occasionally miss a required tool call compared to a
  larger hosted model.
- The knowledge base is a small, synthetic demo set (12 documents) intended
  to illustrate the pipeline, not to cover every real-world IT issue.

## 18. Future Enhancements (not implemented)

- Integration with real IT ticketing systems (e.g. Jira Service Management,
  Zendesk).
- Real-time system monitoring instead of a static mock status file.
- Enterprise authentication (SSO / RBAC) for a multi-user deployment.
- Richer observability / tracing of agent decisions (e.g. LangSmith).
- A proper evaluation dataset with quantitative retrieval/answer metrics.
- Feedback-based retrieval improvement (e.g. re-ranking from user ratings).
- Multi-agent workflows (e.g. a dedicated escalation/triage agent).
- Deployment to cloud infrastructure.

## 19. GitHub Repository

**GitHub Repository:**
https://github.com/KARTHIKAKRISHNA123/resolve-it

## 20. Author

**Karthika Krishna M (KK)**
B.E. Computer Science and Engineering, Anna University Regional Campus, Tirunelveli
GitHub: [@KARTHIKAKRISHNA123](https://github.com/KARTHIKAKRISHNA123)
