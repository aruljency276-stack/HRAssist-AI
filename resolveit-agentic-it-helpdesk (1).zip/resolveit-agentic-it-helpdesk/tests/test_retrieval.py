"""
test_retrieval.py
==================

WHAT: Basic tests for the RAG retrieval pipeline (ingestion + retriever).
WHY:  Ensures document loading/parsing and vector search behave as expected
      before relying on them inside the agent.

NOTE: These tests require `python ingest.py` to have been run at least once
      (so the Chroma DB exists) and a running local Ollama server with the
      embedding model pulled, since real embedding calls are made. They are
      written as plain functions runnable with pytest: `pytest tests/`.
"""

import pytest

from src.ingestion import load_documents, split_documents
from src.config import settings
from src.retriever import search_knowledge_base, VectorStoreNotInitializedError


def test_load_documents_returns_metadata():
    docs = load_documents(settings.knowledge_base_dir)
    assert len(docs) >= 8, "Expected at least 8 knowledge base documents."
    for doc in docs:
        assert doc.metadata.get("document_id")
        assert doc.metadata.get("title")
        assert doc.metadata.get("category")


def test_split_documents_produces_chunks():
    docs = load_documents(settings.knowledge_base_dir)
    chunks = split_documents(docs)
    assert len(chunks) >= len(docs), "Splitting should not reduce document count."
    for chunk in chunks:
        assert chunk.metadata.get("chunk_id")


def test_search_relevant_query_returns_results():
    try:
        results = search_knowledge_base("wifi connected but no internet")
    except VectorStoreNotInitializedError:
        pytest.skip("Chroma DB not built yet. Run `python ingest.py` first.")
    assert len(results) > 0
    # The top result should plausibly relate to networking/wifi.
    top_titles = [r["title"].lower() for r in results]
    assert any("wi-fi" in t or "network" in t or "dns" in t for t in top_titles)


def test_search_empty_query_raises_value_error():
    with pytest.raises(ValueError):
        search_knowledge_base("")


def test_search_unrelated_query_still_returns_results_but_low_relevance():
    """Even an out-of-scope query (e.g. about payroll) will return the
    closest chunks Chroma can find, since similarity search always returns
    the top-k nearest vectors. This test documents that behavior: the
    AGENT is responsible for judging whether those chunks are actually
    relevant (see prompts.py rule 4), not the retriever itself."""
    try:
        results = search_knowledge_base("how do I request vacation days")
    except VectorStoreNotInitializedError:
        pytest.skip("Chroma DB not built yet. Run `python ingest.py` first.")
    assert isinstance(results, list)
