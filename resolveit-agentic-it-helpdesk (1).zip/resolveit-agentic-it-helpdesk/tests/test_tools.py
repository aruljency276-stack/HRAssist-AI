"""
test_tools.py
=============

WHAT: Tests for the two agent tools (search_troubleshooting_knowledge and
      check_system_status), independent of the LLM/agent graph.
WHY:  Tools should be reliable, pure-ish functions with predictable error
      handling, since the agent's grounding depends entirely on them
      returning trustworthy data (or a clear error string) rather than
      throwing unhandled exceptions into the agent loop.
"""

import json
import os

import pytest

from src.tools import check_system_status, search_troubleshooting_knowledge
from src.config import settings
from src.retriever import VectorStoreNotInitializedError


def test_check_system_status_known_system():
    result = check_system_status.invoke({"system_name": "vpn"})
    assert "vpn" in result.lower()
    assert "status" in result.lower()


def test_check_system_status_case_insensitive():
    result = check_system_status.invoke({"system_name": "VPN"})
    assert "TOOL_ERROR" not in result


def test_check_system_status_unknown_system():
    result = check_system_status.invoke({"system_name": "not_a_real_system"})
    assert "TOOL_ERROR" in result
    assert "Unknown system" in result


def test_check_system_status_missing_file(tmp_path, monkeypatch):
    # Point the settings at a file that does not exist, to exercise the
    # missing-file error path.
    monkeypatch.setattr(settings, "system_status_file", str(tmp_path / "missing.json"))
    result = check_system_status.invoke({"system_name": "vpn"})
    assert "TOOL_ERROR" in result
    assert "not found" in result.lower()


def test_check_system_status_reflects_json_contents():
    with open(settings.system_status_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    for system, status in data.items():
        result = check_system_status.invoke({"system_name": system})
        assert status in result


def test_search_tool_handles_empty_query_gracefully():
    result = search_troubleshooting_knowledge.invoke({"query": ""})
    assert "TOOL_ERROR" in result


def test_search_tool_returns_text_or_clear_error():
    result = search_troubleshooting_knowledge.invoke({"query": "printer not responding"})
    # Either we get formatted source blocks, a "no relevant documents"
    # message, or (if the DB hasn't been built in this environment) a clear
    # TOOL_ERROR - never a raw traceback.
    assert isinstance(result, str)
    assert len(result) > 0
